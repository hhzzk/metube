        <div class="col-sm-3 col-md-2 sidebar">
			<div class="top-navigation">
				<div class="t-menu">MENU</div>
				<div class="t-img">
					<img src="images/lines.png" alt="" />
				</div>
				<div class="clearfix"> </div>
			</div>
				<div class="drop-navigation drop-navigation">
				  <ul class="nav nav-sidebar">
					<li class="active"><a href="index.php" class="home-icon"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
                    <li><a href="user.php?main=playlist" class="sub-icon"><span class="glyphicon glyphicon-home glyphicon-hourglass" aria-hidden="true"></span>Playlist</a></li>
                    <li><a href="user.php?main=subscription" class="song-icon"><span class="glyphicon glyphicon-music" aria-hidden="true"></span>Subscription</a></li>
					<li><a href="user.php?main=upload" class="news-icon"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Upload</a></li>
					<li><a href="user.php?main=liked" class="news-icon"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Liked</a></li>
					<li><a href="user.php?main=history" class="news-icon"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>History</a></li>
					<li><a href="user.php?main=profile" class="news-icon"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Profile</a></li>
					<li><a href="user.php?main=message" class="news-icon"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Message</a></li>
					<li><a href="user.php?main=group" class="news-icon"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Group</a></li>
					<li><a href="user.php?main=contact" class="news-icon"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Contact</a></li>
				  </ul>
				  <!-- script-for-menu -->
						<script>
							$( ".top-navigation" ).click(function() {
							$( ".drop-navigation" ).slideToggle( 300, function() {
							// Animation complete.
							});
							});
						</script>
					<div class="side-bottom">
						<div class="side-bottom-icons">
							<ul class="nav2">
								<li><a href="#" class="facebook"> </a></li>
								<li><a href="#" class="facebook twitter"> </a></li>
								<li><a href="#" class="facebook chrome"> </a></li>
								<li><a href="#" class="facebook dribbble"> </a></li>
							</ul>
						</div>
						<div class="copyright">
							<p>Copyright © 2015 My Play. All Rights Reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p>
						</div>
					</div>
				</div>
        </div>
