<div class="col-md-offset-2 main">
    <div class="main-grids">
	    <div class="top-grids">
	        <div class="recommended-info">
	            <h3>funny vedio1.mp4</h3>
            </div>

<div class="container">
            <div class="col-sm-12">
		    
<div class="alert alert-success h5" role="alert">
  <strong>Jinrui:</strong> This vedio is so funny.
</div>
<div class="alert alert-success h5" role="alert">
  <strong>wang2:</strong> Totally agree.
</div>
<div class="alert alert-success h5" role="alert">
  <strong>Jinrui:</strong> Haha 
</div>

		    <div class="panel-footer clearfix">
                    <textarea class="form-control" rows="3"></textarea>
                    <span class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-xs-12" style="margin-top: 10px">
                        <button class="btn btn-warning btn-lg btn-block" id="btn-chat">Send</button>
                    </span>
                </div>
		    
            </div>
        </div>


  </div>
  </div>
  </div>
  
