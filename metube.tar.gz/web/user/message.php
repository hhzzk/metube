<div class="col-md-offset-2 main">
    <div class="main-grids">
	    <div class="top-grids">
	        <div class="recommended-info">
	            <h3>Send Messages</h3>
            </div>

<div class="container">
            <div class="col-sm-12">


                <div class="bs-calltoaction bs-calltoaction-primary">
                    <div class="row">
                        <div class="col-md-9 cta-contents">
                            <h1 class="cta-title h4">Jinrui</h1>
                            <div class="cta-desc h5">
                                <p>Hello, wang2 this is a test.Hello, wang2 this is a test. Hello, wang2 this is a test </p>
                            </div>
                        </div>
                        <div class="col-md-3 cta-button">
                            <a href="#" class="btn btn-lg btn-block btn-primary">Reply</a>
                        </div>
                     </div>
                </div>
                <hr>
                <div class="bs-calltoaction bs-calltoaction-warning">
                    <div class="row">
                        <div class="col-md-9 cta-contents">
                            <h1 class="cta-title h4">Jinrui</h1>
                            <div class="cta-desc h5">
                                <p>Test again, how are you?</p>
                            </div>
                        </div>
                        <div class="col-md-3 cta-button">
                            <a href="#" class="btn btn-lg btn-block btn-warning">Reply</a>
                        </div>
                     </div>
                </div>
                <hr>

            </div>
        </div>


  </div>
  </div>
  </div>
  
